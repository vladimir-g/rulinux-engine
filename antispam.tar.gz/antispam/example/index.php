<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <title>Antispam Example</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  </head>
  <body>
<?
include('../../lor2/incs/db.inc.php');
include('../antispam.class.php');

$aspm = new antispam;
$text = $aspm->go($_POST['content']);
if($text === false)
    echo 'Spam failed';
else
    echo 'Text Accepted';
?>
<form action="index.php" method="POST">
        <table border="0">
            <tbody>
                <tr>
                    <td style="vertical-align:top">Title:</td>
                    <td><input type="text" name="title" value="" style="width:100%" /></td>
                </tr>
                <tr>
                    <td style="vertical-align:top">Content:</td>
                    <td>
                        <textarea name="content" rows="15" cols="50"><?=$_POST['content']?></textarea>
                    </td>
                </tr>
            </tbody>
        </table>
<?
$aspm->add_hiddens();
?>
        <input type="submit" value="Try to send data" />
    </form>
  </body>
</html>
