-- phpMyAdmin SQL Dump
-- version 2.11.3
-- http://www.phpmyadmin.net
--
-- Хост: localhost:3306
-- Время создания: Май 25 2009 г., 02:37
-- Версия сервера: 5.0.75
-- Версия PHP: 5.2.9-4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- База данных: `cms`
--

-- --------------------------------------------------------

--
-- Структура таблицы `as_expressions`
--

CREATE TABLE IF NOT EXISTS `as_expressions` (
  `id` int(11) NOT NULL auto_increment,
  `action` int(1) NOT NULL,
  `words` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `as_expressions`
--

INSERT INTO `as_expressions` (`id`, `action`, `words`) VALUES
(1, 1, '[url|porn');

-- --------------------------------------------------------

--
-- Структура таблицы `as_sessions`
--

CREATE TABLE IF NOT EXISTS `as_sessions` (
  `sid` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `time` int(255) NOT NULL,
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `as_sessions`
--

